![PRINCE-MD](https://readme-typing-svg.demolab.com?font=Poppins&size=24&pause=800&color=008080&center=true&vCenter=true&width=600&lines=🥰+ASSALAMUALAIKUM+❣️+EVERYONE+👋🏻;😍+WELCOME+TO+PRINCE+MD+BOT+💙;🔥+THE+ULTIMATE+WHATSAPP+BOT+EXPERIENCE!;🎉+ENJOY+UNLIMITED+FEATURES+AND+COMMANDS!;💡+FAST+%7C+RELIABLE+%7C+USER-FRIENDLY+BOT!;✨+LET'S+GET+STARTED!)


<div align="center" style="margin: 20px; font-family: Arial, sans-serif;">
    <a href="" style="text-decoration: none;">
        <img 
            alt="PRINCE" 
            width="700" 
            height="400" 
            src="https://i.imgur.com/iI086tX.jpeg" 
            style="border: 3px solid #000; border-radius: 15px; box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3); transition: transform 0.3s ease, box-shadow 0.3s ease;"
            onmouseover="this.style.transform='scale(1.05)'; this.style.boxShadow='0 8px 16px rgba(0, 0, 0, 0.4)';"
            onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 6px 12px rgba(0, 0, 0, 0.3)';"
        >
    </a>
    <p style="margin-top: 10px; font-size: 18px; color: #333;">𝙅𝘼𝙕𝘼𝙆𝘼𝙇𝙇𝘼𝙃 𝙏𝙊 𝘿𝘼𝙎𝙏𝘼𝙂𝙀𝙀𝙍 𝙁𝙊𝙍 𝙏𝙃𝙄𝙎 𝘽𝙊𝙏</p>
</div>



<div align="center">
    <a href="https://github.com/DASTAGHIR/PRINCEMD">
        <img title="Author" src="https://img.shields.io/badge/𝑷𝑹𝑰𝑵𝑪𝑬%20𝑴𝑫%20𝑩𝑶𝑻-black?style=for-the-badge&logo=github">
    </a>
    <br>
    <a href="https://github.com/DASTAGHIR?tab=followers">
        <img title="Followers" src="https://img.shields.io/github/followers/DASTAGHIR?label=Followers&style=social">
    </a>
    <a href="https://github.com/DASTAGHIR/PRINCEMD/stargazers/">
        <img title="Stars" src="https://img.shields.io/github/stars/DASTAGHIR/PRINCEMD?style=social">
    </a>
    <a href="https://github.com/DASTAGHIR/PRINCEMD/network/members">
        <img title="Fork" src="https://img.shields.io/github/forks/DASTAGHIR/PRINCEMD?style=social">
    </a>
    <a href="https://github.com/DASTAGHIR/PRINCEMD/watchers">
        <img title="Watching" src="https://img.shields.io/github/watchers/DASTAGHIR/PRINCEMD?label=Watching&style=social">
    </a>
</div>

<h1 align="center" style="font-family: 'Arial', sans-serif; color: #1a73e8;">𝑷𝑹𝑰𝑵𝑪𝑬-𝑴𝑫-𝑩𝑶𝑻</h1>

<div align="center">
    <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
    <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
</div>

<div align="left">
    
   ### 🟢🟣🔵 𝘾𝙇𝙄𝘾𝙆 𝘼𝙉𝘿 𝙒𝘼𝙄𝙏 𝙏𝙊 𝙊𝙋𝙀𝙉 𝙏𝙃𝙀 𝙎𝙄𝙏𝙀📳
   <br>
    <br>
</div>
<br>

### 💻𝗖𝗟𝗜𝗖𝗞 𝗛𝗘𝗥𝗘 𝗧𝗢 𝗚𝗘𝗧 𝗣𝗥𝗜𝗡𝗖𝗘 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘
[![DATABASE_URL](https://img.shields.io/badge/DATABASE_URL-blue?style=for-the-badge&logo=github)](https://github.com/DASTAGHIR/PRINCE-DATABASE-URL)

<br>
    <br>

<div align="left">
    
 ### 🟣 𝙎𝙃𝙊𝙍𝙏 𝙎𝙀𝙎𝙎𝙄𝙊𝙉 𝙁𝙊𝙍 𝙃𝙀𝙍𝙊𝙆𝙐
   <h3 style="color: #430098;">𝙋𝘼𝙄𝙍 𝘾𝙊𝘿𝙀1️⃣</h3>
    <a href="https://short-pair-for-heorku.onrender.com">
        <img height="30" title="Session" src="https://img.shields.io/badge/𝗦𝗘𝗦𝗦𝗜𝗢𝗡-purple?style=for-the-badge&logo=heroku&logoColor=white">
    </a>
</div>
<br>
<div align="left">
    <h3 style="color: #34a853;">𝙋𝘼𝙄𝙍 𝘾𝙊𝘿𝙀2️⃣</h3>
    <a href="https://embarrassed-corliss-secktor-ead5ff5a.koyeb.app/">
        <img height="30" title="Session" src="https://img.shields.io/badge/𝗦𝗘𝗦𝗦𝗜𝗢𝗡-red?style=for-the-badge&logo=heroku&logoColor=white">
    </a>
    <br>
</div>
<br>
<br>
<div align="left">
       
 ### 🔵 𝙇𝙊𝙉𝙂 𝙎𝙀𝙎𝙎𝙄𝙊𝙉 𝙁𝙊𝙍 𝙋𝘼𝙉𝙀𝙇𝙎 𝘼𝙉𝘿 𝘼𝙇𝙇 𝙋𝙇𝘼𝙏𝙁𝙊𝙍𝙈𝙎
   
</div>
   
<div align="left">
    <h3 style="color: #34a853;">𝙋𝘼𝙄𝙍 𝘾𝙊𝘿𝙀1️⃣</h3>
    <a href="https://prince-new-base64-pair.onrender.com">
        <img height="30" title="Session" src="https://img.shields.io/badge/𝗦𝗘𝗦𝗦𝗜𝗢𝗡-skyblue?style=for-the-badge&logo=render">
    </a>
    <br>
    <h3 style="color: #34a853;">𝙋𝘼𝙄𝙍 𝙌𝙍 𝘾𝙊𝘿𝙀2️⃣</h3>
    <a href="https://prince-session-base64.onrender.com">
        <img height="30" title="Session" src="https://img.shields.io/badge/𝗦𝗘𝗦𝗦𝗜𝗢𝗡-green?style=for-the-badge&logo=render">
    </a>
</div>

<div align="center">
    <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
    <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
</div>

<div align="center">
    
### 𝘿𝙀𝙋𝙇𝙊𝙔𝙈𝙀𝙉𝙏 𝙊𝙋𝙏𝙄𝙊𝙉𝙎
</div>
<div align="center">
    <a href="https://gd-sdeploy.vercel.app/">
        <img height="30" title="Heroku" src="https://img.shields.io/badge/𝗛𝗘𝗥𝗢𝗞𝗨-9966CC?style=for-the-badge&logo=render">
    </a>
    <a href="https://repl.it/github/DASTAGHIR/PRINCEMD">
        <img height="30" title="Replit" src="https://img.shields.io/badge/𝗥𝗘𝗣𝗟𝗜𝗧-orange?style=for-the-badge&logo=replit">
    </a>
    <a href="https://dashboard.render.com/blueprint/new?repo=https%3A%2F%2Fgithub.com%2FDASTAGHIR%2FPRINCEMD">
        <img height="30" title="Render" src="https://img.shields.io/badge/𝗥𝗘𝗡𝗗𝗘𝗥-E6E6FA?style=for-the-badge&logo=render">
    </a>
</div>

<div align="center">
    
### 𝙍𝙐𝙉 𝙊𝙉 𝙆𝙊𝙔𝙀𝘽

<div align="center">
    <p align="center">
        <a href="https://app.koyeb.com/deploy?type=git&repository=https://github.com/DASTAGHIR/PRINCEMD&branch=main&name=princegds&builder=dockerfile&env[OWNERS]=923092668108%3B%E2%9D%A3%EF%B8%8FDASTAGEER&env[MODE]=public&env[PREFIX]=&env[antidelete]=false&env[ANTI_LINK]=false&env[AUTOREAD]=false&env[VIEWONCE]=false&env[STATUS_REPLY]=false&env[STATUSLIKES]=true&env[STATUS_MSG]=Your+Status+has+been+seen+by+Prince+bot&env[BOT_NAME]=PRINCE-MD&env[PACK_NAME]=Princebot%F0%9F%8E%97%EF%B8%8F%E2%9D%A3%EF%B8%8F&env[DL_MSG]=_📥--------+*DOWNLOADED+SUCCESSFULLY*+--------📥_&env[STATUSVIEW]=false&env[Status_Saver]=false&env[REJECTSCALLS]=false&env[AutoReaction]=false&env[SESSION_ID]=">
            <img src="https://www.koyeb.com/static/images/deploy/button.svg" height="45"/>
        </a>
    </p>
</div>

<div align="center">
    
### 🟢 𝙎𝙐𝙋𝙋𝙊𝙍𝙏 𝙂𝙍𝙊𝙐𝙋 𝙇𝙄𝙉𝙆 🟢

</div>






<p align="center">
    <a href="https://chat.whatsapp.com/Jo5bmHMAlZpEIp75mKbwxP">
        <img height="30" title="Support Group" src="https://img.shields.io/badge/Support%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white">
    </a>
</p>

<div align="center">
    <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
    <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
</div>

### 𝗟𝗜𝗖𝗘𝗡𝗦𝗘: [Click here](https://github.com/PRINCE-GDS/PRINXE-MD/blob/main/LICENSE)

<div align="left">
    <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
    <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
</div>

### 💠 [`𝗔𝗩𝗔𝗜𝗟𝗔𝗕𝗟𝗘 𝗟𝗔𝗡𝗚𝗨𝗔𝗚𝗘𝗦 𝗙𝗢𝗥 𝗣𝗥𝗜𝗡𝗖𝗘 𝗕𝗢𝗧`]
- 🪄 Arabic = ar 
- 🪄 Urdu = ur
- 🪄 English Global = en
- 🪄 Bahasa Indonesia = id
- 🪄 Portuguese = pt
- 🪄 Spanish = es

<div align="left">
    <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
    <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
</div>
